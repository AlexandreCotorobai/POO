package Aula08;

public interface KmPercorridosInterface {
    void trajeto(int quilometros);
    int ultimoTrajeto();
    int distanciaTotal();
}
