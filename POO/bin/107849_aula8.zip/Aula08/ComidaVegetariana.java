package Aula08;

public interface ComidaVegetariana {
    public boolean isVegetarian();
}
