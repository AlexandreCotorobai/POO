package Aula08;

public interface VeiculoEletrico {
    int autonomia();
    void carregar(int percentagem);
}
