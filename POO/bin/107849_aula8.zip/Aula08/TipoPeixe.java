package Aula08;

public enum TipoPeixe {
    CONGELADO, FRESCO
}

