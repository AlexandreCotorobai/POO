package Aula07;

public abstract class Date {
    abstract int getYear();
    abstract int getMonth();
    abstract int getDay();
    abstract void decrement();
    abstract void increment();
}
