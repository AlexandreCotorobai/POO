package Aula07;

public abstract class DateAbstract implements Comparable<DateAbstract>{
    abstract int getYear();
    abstract int getMonth();
    abstract int getDay();
    abstract void decrement();
    abstract void increment();
}
